export class Party
{
    partyId:any;
    partyName:string;
    partyType:string;
    subcity:string;
    workingStation:string;
    phoneNumber:any;
    address:string;
    partyStatus:string;
}
export class PartyType
{
    partyTypeId:string;
    partyTypeName:string;
}