import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-admin',
  template: `<router-outlet></router-outlet>`
  
  ,
})
export class AdminComponent{

}
